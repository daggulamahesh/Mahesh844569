package com.egg.controller;

import java.util.List;

import java.util.Optional;

import org.hibernate.validator.constraints.pl.REGON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ShoppingCart;
import com.egg.service.ShoppingCartService;



@RestController
public class ShoppincartController {
	
	@Autowired
	ShoppingCartService cartService;
	
	@GetMapping("/{buyerid}/getall")
	public List<ShoppingCart> getAllCartItems(@PathVariable("buyerid") Integer id)
	{
		return cartService.getAllCart(id);
	}
	@PostMapping("/{buyerid}/additem")
	public ShoppingCart addItemToCart(@PathVariable("buyerid") Integer id,@RequestBody ShoppingCart cart)
	{ Optional<ShoppingCart> cart1 = cartService.addItemToCart(id, cart);
		return cart1.get();
	}

	 @DeleteMapping("/{cartid}/deleteitem")
	 public void DeleteItemincart(@PathVariable("cartid") Integer carttemId)
	 {
		 cartService.DeleteItemIncart(carttemId);
	 }
	
	 @PutMapping("/{CartItemid}/update")
	 public ShoppingCart updateCart(@RequestBody ShoppingCart shoppingcart,@PathVariable("CartItemid") Integer id)
	 {
		 return cartService.UpdateCart(shoppingcart, id);
	 }
	 
	 @DeleteMapping("/{buyerid}/emptycart")
	public  void emptyCart(@PathVariable("buyerid") Integer id)
	{
		 cartService.emptyCart(id);
	}
	 
	 @PostMapping("/{buyerid}/checkout")
	 public void checkoutcart(@PathVariable("buyerid") Integer id)
	 {
		 cartService.CheckoutCart(id);
	 }
	 
	 
}
