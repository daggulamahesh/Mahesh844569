package com.egg.service;

import java.util.Arrays;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.IBuyerDao;
import com.egg.model.BuyerEntity;


@Service(value = "userService")
public class BuyerService implements UserDetailsService , IBuyerService {
	
	@Autowired
	private IBuyerDao buyerdao;
	
	
	/*---------------------------------------*/
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerEntity user = buyerdao.findByuserName(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	  @Override public BuyerEntity createBuyer(BuyerEntity buyer) {
	  
		  buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
	  return buyerdao.save(buyer);
	  }
	 

	@Override
	public BuyerEntity updateBuyer(BuyerEntity buyer) {

		Optional<BuyerEntity> buyerobject = buyerdao.findById(buyer.getBuyerId());
		BuyerEntity buyer1 = null;
		if(buyerobject.isPresent()) {
			buyer1 = buyerobject.get();
			buyer1.setUserName(buyer.getUserName());
			buyer1.setEmail(buyer.getEmail());
			buyer1.setMobileNumber(buyer.getMobileNumber());
			 BeanUtils.copyProperties(buyer, buyerobject, "password");
			//buyer1.setPassword(buyer.getPassword());
			 buyer1= buyerdao.save(buyer1);
		}
		return buyer1;
	
	}

	@Override
	public void deleteById(Integer buyerId) {
		Optional<BuyerEntity> buyerid = buyerdao.findById(buyerId);
		
		if(buyerid.isPresent())
		{
			buyerdao.deleteById(buyerId);
		}
		
		
	}

	@Override
	public BuyerEntity findOne(String username) {
		
		return buyerdao.findByuserName(username);
	}

	@Override
	public BuyerEntity findById(int id) {
		
		Optional<BuyerEntity> buyer = buyerdao.findById(id);
            return buyer.isPresent() ? buyer.get() : null;
	}
	


	
	
}
