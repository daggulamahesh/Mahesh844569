package com.egg.service;

import java.util.Optional;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.egg.dao.IBuyerDao;
import com.egg.dao.ITransactionDao;
import com.egg.exception.ResourceNotFoundException;
import com.egg.model.TransactionEntity;





@Service
public class TransactionImplementation implements ITranscation {

	@Autowired
	private ITransactionDao transactiondao;
	
	@Autowired
	private IBuyerDao buyerdao;

	/*
	 * @Override public Page<TransactionEntity> findByBuyerId(Integer buyerId,
	 * Pageable pageable) {
	 * 
	 * return transactiondao.findBybuyerentity(buyerId, pageable); }
	 */
	/*
	 * @Override public Optional<TransactionEntity> findByIdAndbuyerId(Integer
	 * transactionId, Integer buyerId) { // TODO Auto-generated method stub return
	 * transactiondao.findByIdAndbuyerId(transactionId, buyerId); }
	 */
	@Override
	public TransactionEntity createTransaction(int id,TransactionEntity transaction) {
		/*
		 * TODO Auto-generated method stub Optional<BuyerEntity> buyerobject =
		 * buyerdao.findById(id);
		 */
		return buyerdao.findById(id).map(buyerentity -> {
			transaction.setBuyerentity(buyerentity);
            return transactiondao.save(transaction);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + id + " not found"));
	}

	/*
	 * @Override public void deleteById(Integer transactionId) {
	 * 
	 * 
	 * }
	 */

}
