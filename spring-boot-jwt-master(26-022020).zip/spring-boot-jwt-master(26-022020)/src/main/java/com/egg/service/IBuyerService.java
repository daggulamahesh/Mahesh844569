package com.egg.service;

import org.springframework.web.bind.annotation.PathVariable;


import com.egg.model.BuyerEntity;




public interface IBuyerService {
	
	
	BuyerEntity createBuyer(BuyerEntity buyer);
	BuyerEntity  updateBuyer(BuyerEntity buyer);
	void  deleteById(Integer buyerId );
	BuyerEntity  findOne(String username);

	BuyerEntity findById(int id);
	

}
