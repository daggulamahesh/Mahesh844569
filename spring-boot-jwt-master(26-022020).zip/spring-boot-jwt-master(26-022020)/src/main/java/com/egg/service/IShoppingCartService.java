package com.egg.service;


import java.util.List;


import java.util.Optional;

import com.egg.model.ShoppingCart;



public interface IShoppingCartService {

	void DeleteItemIncart(Integer carditemId);
	ShoppingCart UpdateCart(ShoppingCart shoppingcartitem,Integer CaritemtId);
	void CheckoutCart(Integer buyerid);
	Optional<ShoppingCart> addItemToCart(Integer buyerId,ShoppingCart shoppincart);
	List<ShoppingCart> getAllCart(Integer BuyerId);
	void emptyCart(Integer buyerId);
}
