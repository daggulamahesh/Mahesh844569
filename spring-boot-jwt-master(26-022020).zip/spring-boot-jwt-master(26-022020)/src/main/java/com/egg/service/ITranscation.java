package com.egg.service;

import java.util.Optional;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.egg.model.TransactionEntity;



//import com.cts.Entity.BuyerEntity;
//import com.cts.Entity.TransactionEntity;


public interface ITranscation {
	
	/* Page<TransactionEntity> findByBuyerId(Integer buyerId, Pageable pageable); */

	/*
	 * Optional<TransactionEntity> findByIdAndbuyerId(Integer transactionId, Integer
	 * buyerId);
	 */
    TransactionEntity   createTransaction(int id,TransactionEntity transaction);
	
	//BuyerEntity  updateBuyer(BuyerEntity buyer);
	/* void deleteById(Integer transactionId ); */
	
	

}
