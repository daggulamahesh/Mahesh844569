export class Item {
   id: number;
   name: string;
   price: string;
   description: string;
   company: string;
   constructor() { 
   }
}