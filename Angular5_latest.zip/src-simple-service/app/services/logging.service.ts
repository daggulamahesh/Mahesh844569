import { Injectable } from '@angular/core';

@Injectable()  
export class LoggingService {  
  
  constructor() { }  
  
   funLog():void{  
  
    console.log('This is a new Service for Loging111111111111');
  } 
}   