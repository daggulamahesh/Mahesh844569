import { Injectable } from '@angular/core';

@Injectable()  
export class MathematicsService {  
  
  constructor() { }  
  
   fun1():void{  
  
    console.log('This is from Service');
  }  
  
}   