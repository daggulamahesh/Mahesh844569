import { TestBed, async, inject} from '@angular/core/testing';
import { LanguagesService } from './lang.service';
//import {addProviders, inject} from '@angular/core/testing';


describe('Service: LanguagesService', () => {
    let service;
    
    //setup
    beforeEach(() => {
        TestBed.configureTestingModule({
          providers: [LanguagesService]
        });
      });
    
    //specs
    it('should be contaning languages', inject([LanguagesService], (service : LanguagesService) => {
      let languages = service.get();
      expect(languages).toContain('en');
      expect(languages).toContain('es');
      expect(languages).toContain('fr');
      expect(languages.length).toEqual(3);
    }));
  });
