import { Injectable } from '@angular/core';

@Injectable()  
//a simple service
export class LanguagesService {
  get() {
    return ['en', 'es', 'fr'];
  }
}