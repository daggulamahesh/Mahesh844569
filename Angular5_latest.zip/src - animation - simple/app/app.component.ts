import {Component, trigger, state, style, transition, animate} from '@angular/core';
/* [tx, ty, tz], where tx is the translation along the x-axis, 
ty is the translation along the y-axis, and tz is the translation along the z-axis. 
The values tx, ty, and tz are provided either as a <length> or as a percentage.
*/
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        borderColor: '#000',
		borderWidths: '2px',
		opacity: 0.2, backgroundColor: '#000', transform: 'translate3d(30%, 0, 0) scale(1)'
      })),
      state('out', style({
		  borderColor: '#0F0',
		  borderWidths: '4px',
        opacity: 0.8,backgroundColor: '#F00', transform: 'translate3d(100%, 10%, 0) scale(2)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class AppComponent {
  title = 'app works!';

  menuState:string = 'out';

  toggleMenu() {
	  console.log("in toggle menu")
    // 1-line if statement that toggles the value:
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
	
  }
}
