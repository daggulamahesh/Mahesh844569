import { Component } from '@angular/core';

@Component({
  selector: 'my-root',
  templateUrl: './app.component1.html'
})
export class AppComponent1 {
  title = 'app';
}
