import {Injectable}               from '@angular/core';
import {HttpClient, Response}           from '@angular/http';
import {Headers, RequestOptions}  from '@angular/http';
import {Observable}               from 'rxjs/Observable';

import {Todo}                     from './todo';

@Injectable()
export class TodoService {
  
  constructor (private http: HttpClient) {}

  private _todosUrl = './todos.json';

  getTodos () {
    return this.http.get(this._todosUrl)
              .toPromise()
              .then(res => <Todo[]> res.json().data)
              .then(data => { console.log(data); return data; }); // eyeball results in the console
  }

  private handleError (error: Response) {
    console.error(error);
    return Observable.throw(error.json().error || 'Server error');
  }
}