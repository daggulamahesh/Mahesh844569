import {Component} from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html', 
    styleUrls: ['app.component.css']
})
export class AppComponent {
    isValid = true;
    ids = [1,2,3,4];		
    emp1 = new Employee(100, 'Nilesh');
    emp2 : Employee;
} 


export class Employee {
  constructor(public id: number, public name: string) { 
  }
}