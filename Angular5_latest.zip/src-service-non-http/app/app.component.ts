import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  template: `              
			    <store-app> </store-app> 			   
			    <cart-app> </cart-app> 			  
           `
})
export class AppComponent { 
}
    