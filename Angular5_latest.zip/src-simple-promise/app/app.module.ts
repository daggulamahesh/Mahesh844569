import {BrowserModule} from '@angular/platform-browser';
import {NgModule}      from '@angular/core';

import {AppComponent}  from './app.component';
import { SearchService } from './services/search.service';
import { HttpModule } from '@angular/http';


@NgModule({
  imports: [     
        BrowserModule, HttpModule
  ],
  declarations: [
        AppComponent
  ],
  providers: [
      SearchService
  ],
  bootstrap: [
        AppComponent
  ]
})
export class AppModule { }
