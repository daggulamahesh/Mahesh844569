import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    Status: boolean = true; 
    myFunc(event) { 
	if(this.Status)
	{
        this.Status = false; 
	}
	else
	{
		this.Status = true;
	}
    } 
}